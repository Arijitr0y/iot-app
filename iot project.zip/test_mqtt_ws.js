import mqtt from 'mqtt';

const url = 'wss://mqtt.arijitroy.dpdns.org/mqtt';
const options = {
  username: 'web_client',
  password: 'WebClientPass123',
  clientId: 'test_node_script',
  rejectUnauthorized: false
};

console.log('Connecting to', url);
const client = mqtt.connect(url, options);

client.on('connect', () => {
  console.log('SUCCESS: Connected to MQTT via WebSockets on 443!');
  client.end();
  process.exit(0);
});

client.on('error', (err) => {
  console.error('ERROR:', err.message);
  client.end();
  process.exit(1);
});

setTimeout(() => {
  console.log('TIMEOUT on 443');
  client.end();
  process.exit(0);
}, 5000);
