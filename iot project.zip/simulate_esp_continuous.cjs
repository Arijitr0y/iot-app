const mqtt = require('mqtt');

const client = mqtt.connect('wss://mqtt.arijitroy.dpdns.org/mqtt', {
  username: 'esp8266_node', // Using ESP8266 credentials to ensure publish permission!
  password: 'Test1'
});

client.on('connect', () => {
  console.log('Connected to broker! Publishing simulated ESP8266 message continuously...');
  
  const topic = 'iot/devices/B6E62D44D6A5/state';
  const payload = JSON.stringify({
    id: "B6E62D44D6A5",
    status: "online",
    state: "on",
    water_level: 50
  });

  setInterval(() => {
    client.publish(topic, payload, { retain: true }, (err) => {
      if (err) {
        console.error('Failed to publish:', err);
      } else {
        console.log('Successfully published simulated state to', topic);
      }
    });
  }, 2000);
});

client.on('error', (err) => {
  console.error('MQTT error:', err);
  client.end();
});
