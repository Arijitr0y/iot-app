const mqtt = require('mqtt');

const client = mqtt.connect('wss://mqtt.arijitroy.dpdns.org/mqtt', {
  username: 'web_client',
  password: 'WebClientPass123'
});

client.on('connect', () => {
  console.log('Test Subscriber Connected! Subscribing...');
  client.subscribe('iot/devices/+/state', (err) => {
    if (!err) console.log('Successfully subscribed');
    else console.error('Subscription error:', err);
  });
});

client.on('message', (topic, message) => {
  console.log(`RECEIVED MESSAGE on ${topic}:`, message.toString());
  client.end();
  process.exit(0);
});

// timeout after 5 seconds if no retained message is received
setTimeout(() => {
  console.log('TIMEOUT: No retained message received within 5 seconds.');
  client.end();
  process.exit(1);
}, 5000);
