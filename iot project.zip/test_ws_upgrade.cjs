const https = require('https');

const options = {
  hostname: 'mqtt.arijitroy.dpdns.org',
  port: 443,
  path: '/mqtt',
  method: 'GET',
  headers: {
    'Connection': 'Upgrade',
    'Upgrade': 'websocket',
    'Sec-WebSocket-Key': 'dGhlIHNhbXBsZSBub25jZQ==',
    'Sec-WebSocket-Version': '13'
  }
};

console.log('Sending WebSocket Upgrade Request to', options.hostname);

const req = https.request(options, (res) => {
  console.log(`STATUS: ${res.statusCode}`);
  console.log(`HEADERS: ${JSON.stringify(res.headers)}`);
  res.on('data', (chunk) => {
    console.log(`BODY: ${chunk}`);
  });
  process.exit(0);
});

req.on('upgrade', (res, socket, upgradeHead) => {
  console.log('Got UPGRADE response!');
  console.log(`HEADERS: ${JSON.stringify(res.headers)}`);
  socket.end();
  process.exit(0);
});

req.on('error', (e) => {
  console.error(`Problem with request: ${e.message}`);
  process.exit(1);
});

req.setTimeout(5000, () => {
  console.log('TIMEOUT: Request timed out');
  req.destroy();
  process.exit(1);
});

req.end();
