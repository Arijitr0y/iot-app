import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { WelcomeCard } from './components/WelcomeCard';
import { DeviceList, Device } from './components/DeviceList';
import { Button } from '@/components/ui/button';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Plus, AlertCircle } from 'lucide-react';
import { mqttService } from '@/services/mqtt.service';
import { supabase } from '@/lib/supabase';

export const Dashboard = () => {
  const [devices, setDevices] = useState<Device[]>([]);
  const [deviceError, setDeviceError] = useState<{ id: string, message: string } | null>(null);

  useEffect(() => {
    let isMounted = true;

    const fetchDevices = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const { data, error } = await supabase
        .from('user_devices')
        .select(`
          id,
          name,
          mac_address,
          relay_state,
          last_seen,
          device_types (
            name,
            ui_component
          )
        `)
        .eq('owner_id', session.user.id);
      
      if (error) {
        console.error('Error fetching devices:', error);
        return;
      }

      if (isMounted && data) {
        const mappedDevices: Device[] = data.map((d: any) => ({
          id: d.mac_address, // Use MAC address as the ID for MQTT correlation
          name: d.name,
          type: d.device_types?.name || 'Unknown Type',
          ui_component: d.device_types?.ui_component || 'default',
          status: 'offline', // Default to offline until MQTT updates it
          lastSeen: d.last_seen ? new Date(d.last_seen).toLocaleTimeString() : 'Never'
        }));
        
        setDevices(mappedDevices);
      }
    };

    fetchDevices();

    // Initialize MQTT connection when dashboard loads
    mqttService.connect().then(() => {
      // Once connected, subscribe to all device state updates using the MQTT wildcard '+'
      mqttService.subscribe('iot/devices/+/state', () => {});
      mqttService.subscribe('iot/devices/+/error', () => {});
    }).catch(console.error);

    // Add a global listener to catch all incoming messages
    const handleGlobalMessage = (topic: string, payload: any) => {
      // We only care about device state announcements
      if (topic.startsWith('iot/devices/') && topic.endsWith('/state')) {
        setDevices(prevDevices => {
          if (!payload.id) return prevDevices;
          
          const existingDevice = prevDevices.find(d => d.id === payload.id);
          const now = new Date().toLocaleTimeString();
          
          if (existingDevice) {
            // Update existing device's status
            return prevDevices.map(d => 
              d.id === payload.id 
                ? { ...d, status: payload.status || 'online', lastSeen: now } 
                : d
            );
          } else {
            // Ignore devices not registered in Supabase
            return prevDevices;
          }
        });
      } else if (topic.startsWith('iot/devices/') && topic.endsWith('/error')) {
        if (payload.error) {
          setDeviceError({ id: payload.id || 'Unknown', message: payload.error });
          setTimeout(() => setDeviceError(null), 5000);
        }
      }
    };

    mqttService.addGlobalListener(handleGlobalMessage);

    return () => {
      isMounted = false;
      mqttService.removeGlobalListener(handleGlobalMessage);
      mqttService.unsubscribe('iot/devices/+/state', () => {});
      mqttService.unsubscribe('iot/devices/+/error', () => {});
    };
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <Button asChild>
          <Link to="/provisioning">
            <Plus className="mr-2 h-4 w-4" /> Add Device
          </Link>
        </Button>
      </div>

      {deviceError && (
        <Alert variant="destructive" className="animate-in slide-in-from-top-2">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Device Error ({deviceError.id})</AlertTitle>
          <AlertDescription>{deviceError.message}</AlertDescription>
        </Alert>
      )}

      <WelcomeCard />

      <DeviceList devices={devices} />
    </div>
  );
};
