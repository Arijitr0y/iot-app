import { supabase } from '@/lib/supabase';
import mqtt from 'mqtt';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';

export const publishMqttMessage = async (topic: string, message: any, options?: mqtt.IClientPublishOptions) => {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.access_token) {
    throw new Error('User not authenticated. Cannot publish to MQTT.');
  }

  const response = await fetch(`${API_URL}/api/mqtt/publish`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${session.access_token}`
    },
    body: JSON.stringify({
      topic,
      message,
      options
    })
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => null);
    throw new Error(errorData?.error || 'Failed to publish MQTT message');
  }

  return response.json();
};
