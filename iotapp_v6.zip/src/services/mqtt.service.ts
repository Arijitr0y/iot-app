import mqtt from 'mqtt';

// Environment variables
const mqttWsUrl = import.meta.env.VITE_MQTT_WS_URL;

let client: mqtt.MqttClient | null = null;
const listeners = new Map<string, Set<(message: any) => void>>();
const globalListeners = new Set<(topic: string, message: any) => void>();

export const mqttService = {
  connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (client?.connected) {
        resolve();
        return;
      }

      if (!mqttWsUrl) {
        console.warn('MQTT WS URL not defined in .env');
        resolve(); // Don't throw to prevent crashing if not setup
        return;
      }

      console.log('Connecting to MQTT via WebSocket:', mqttWsUrl);
      
      const clientId = `web_${Math.random().toString(16).slice(3)}`;
      
      client = mqtt.connect(mqttWsUrl, {
        clientId,
        reconnectPeriod: 5000,
        connectTimeout: 30 * 1000,
        clean: true,
      });

      client.on('connect', () => {
        console.log('Connected to MQTT Broker');
        
        // Subscribe to all topics that components requested before connection was established
        for (const topic of Array.from(listeners.keys())) {
          client?.subscribe(topic);
        }
        
        resolve();
      });

      client.on('error', (err) => {
        console.error('MQTT Connection Error:', err);
        reject(err);
      });

      client.on('message', (topic, message) => {
        try {
          const payload = JSON.parse(message.toString());
          
          // Trigger exact topic listeners
          if (listeners.has(topic)) {
            listeners.get(topic)!.forEach(callback => callback(payload));
          }
          
          // Trigger global listeners (useful for wildcard subscriptions)
          globalListeners.forEach(callback => callback(topic, payload));
        } catch (e) {
          console.warn('Failed to parse MQTT message as JSON', e);
        }
      });
    });
  },

  subscribe(topic: string, callback: (message: any) => void) {
    if (!listeners.has(topic)) {
      listeners.set(topic, new Set());
    }
    listeners.get(topic)!.add(callback);

    if (client?.connected) {
      client.subscribe(topic);
    }
  },

  unsubscribe(topic: string, callback: (message: any) => void) {
    if (listeners.has(topic)) {
      listeners.get(topic)!.delete(callback);
      if (listeners.get(topic)!.size === 0) {
        if (client?.connected) {
          client.unsubscribe(topic);
        }
        listeners.delete(topic);
      }
    }
  },

  disconnect() {
    if (client) {
      client.end();
      client = null;
    }
  },

  addGlobalListener(callback: (topic: string, message: any) => void) {
    globalListeners.add(callback);
  },

  removeGlobalListener(callback: (topic: string, message: any) => void) {
    globalListeners.delete(callback);
  }
};
