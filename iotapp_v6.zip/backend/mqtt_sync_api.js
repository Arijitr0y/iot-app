/**
 * MQTT Configuration Sync API
 * 
 * This Express server acts as a control plane for Mosquitto, enabling EMQX-style
 * dynamic configuration via the React dashboard.
 * 
 * It listens for requests on /api/mqtt/sync, fetches the latest credentials from Supabase,
 * generates the Mosquitto password and ACL files, and triggers a dynamic reload.
 * 
 * Prerequisites on the host VM:
 * - Docker installed and the Mosquitto container named "iot-mosquitto"
 * - The Mosquitto container must have the `mosquitto_passwd` utility available
 * - A shared volume for `/mosquitto/config` between this script (if dockerized) and Mosquitto, 
 *   OR just use `docker exec` for everything.
 */

import express from 'express';
import { createClient } from '@supabase/supabase-js';
import { exec } from 'child_process';
import util from 'util';
import fs from 'fs/promises';
import path from 'path';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import mqtt from 'mqtt';
import { config } from './config.js';

const execPromise = util.promisify(exec);
const app = express();

// Enable CORS for specific origin
app.use(cors({ origin: config.FRONTEND_URL }));
app.use(express.json());

// Rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: { success: false, error: 'Too many requests from this IP, please try again later.' }
});
app.use('/api/', apiLimiter);

const mqttClient = mqtt.connect(config.MQTT_HOST, {
  username: config.MQTT_USERNAME,
  password: config.MQTT_PASSWORD,
  clientId: `backend_api_${Math.random().toString(16).substring(2, 8)}`,
});

mqttClient.on('connect', () => {
  console.log('✅ Backend API Connected to MQTT Broker');
});

mqttClient.on('error', (err) => {
  console.error('MQTT Client Error in API:', err);
});

const supabase = createClient(config.SUPABASE_URL, config.SUPABASE_SERVICE_ROLE_KEY);

const MOSQUITTO_CONFIG_DIR = config.MOSQUITTO_CONFIG_DIR;
const ACL_FILE_PATH = path.join(MOSQUITTO_CONFIG_DIR, 'acl');
const PASSWORDS_FILE_PATH = path.join(MOSQUITTO_CONFIG_DIR, 'passwords');


// NEW ENDPOINT: Secure MQTT Publish
app.post('/api/mqtt/publish', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ success: false, error: 'Unauthorized: Missing Bearer token' });
    }

    const token = authHeader.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return res.status(401).json({ success: false, error: 'Unauthorized: Invalid token' });
    }

    const { topic, message, options } = req.body;
    if (!topic || message === undefined) {
      return res.status(400).json({ success: false, error: 'Missing topic or message' });
    }

    // In a full implementation, you could add RLS-like checks here based on user ID and topic.
    // For now, we authenticate the user and allow them to publish, replicating previous frontend behavior securely.
    
    console.log(`📡 User ${user.email} publishing to ${topic}`);

    mqttClient.publish(topic, typeof message === 'string' ? message : JSON.stringify(message), options || { qos: 1 }, (err) => {
      if (err) {
        console.error('MQTT publish failed:', err);
        return res.status(500).json({ success: false, error: 'MQTT publish failed' });
      }
      res.json({ success: true, message: 'Published successfully' });
    });
  } catch (err) {
    console.error('❌ MQTT publish endpoint error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/mqtt/sync', async (req, res) => {
  try {
    // Ensure docker CLI is available in the environment running this script
    try {
      await execPromise('docker --version');
    } catch (err) {
      throw new Error('Docker CLI is not available in this environment. If running inside a container, you must mount /var/run/docker.sock and install the docker CLI, or run this script directly on the host VM using PM2.');
    }

    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ success: false, error: 'Unauthorized: Missing Bearer token' });
    }

    const token = authHeader.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return res.status(401).json({ success: false, error: 'Unauthorized: Invalid token' });
    }

    // Strict RBAC Admin Check
    const { data: roleData, error: roleErr } = await supabase
      .from('admin_user_roles')
      .select('access_level')
      .eq('user_id', user.id)
      .single();

    if (roleErr || !roleData || roleData.access_level !== 'admin_panel') {
      return res.status(403).json({ success: false, error: 'Forbidden: Insufficient privileges to trigger MQTT sync' });
    }

    console.log(`🔄 Initiating Mosquitto Sync (triggered by ${user.email})...`);

    // 1. Fetch Users and Passwords
    const { data: users, error: usersErr } = await supabase.from('mqtt_users').select('*');
    if (usersErr) throw usersErr;

    // 2. Fetch ACLs
    const { data: acls, error: aclsErr } = await supabase.from('mqtt_acls').select('*');
    if (aclsErr) throw aclsErr;

    // 3. Rebuild the Passwords file
    // We recreate the file from scratch to handle deletions properly
    try {
      await fs.writeFile(PASSWORDS_FILE_PATH, ''); // Clear file
    } catch (e) {
      // If file doesn't exist, it will be created. Ensure dir exists.
      await fs.mkdir(MOSQUITTO_CONFIG_DIR, { recursive: true });
      await fs.writeFile(PASSWORDS_FILE_PATH, '');
    }

    for (const user of users) {
      if (!user.password_hash) continue; // Skip users without a password set

      // Use docker exec to run mosquitto_passwd inside the container
      // -b means batch mode (username password)
      try {
        const { execFile } = await import('child_process');
        const execFilePromise = util.promisify(execFile);
        
        await execFilePromise('docker', [
          'exec', 
          config.MOSQUITTO_CONTAINER_NAME, 
          'mosquitto_passwd', 
          '-b', 
          '/mosquitto/config/passwords', 
          user.username, 
          user.password_hash
        ]);
        console.log(`🔑 Generated credentials for: ${user.username}`);
      } catch (execErr) {
        console.error(`Failed to generate password for ${user.username}:`, execErr.message);
      }
    }

    // 4. Rebuild the ACL file
    let aclContent = '';

    // Group ACLs by user
    const aclsByUser = users.reduce((acc, user) => {
      acc[user.id] = { username: user.username, rules: [] };
      return acc;
    }, {});

    for (const acl of acls) {
      if (aclsByUser[acl.user_id]) {
        aclsByUser[acl.user_id].rules.push(acl);
      }
    }

    for (const userId in aclsByUser) {
      const userAcls = aclsByUser[userId];
      if (userAcls.rules.length > 0) {
        aclContent += `user ${userAcls.username}\n`;
        for (const rule of userAcls.rules) {
          if (rule.access_level === 'readwrite') {
            aclContent += `topic readwrite ${rule.topic_pattern}\n`;
          } else {
            aclContent += `topic ${rule.access_level} ${rule.topic_pattern}\n`;
          }
        }
        aclContent += '\n';
      }
    }

    // Write ACL file
    await fs.writeFile(ACL_FILE_PATH, aclContent);
    console.log(`🛡️ Generated ACL file with ${acls.length} rules.`);

    // 5. Trigger Dynamic Reload (SIGHUP)
    // SIGHUP tells mosquitto to reload configuration, passwords, and ACL files without dropping active connections.
    console.log(`📡 Reloading Mosquitto container (${config.MOSQUITTO_CONTAINER_NAME})...`);
    await execPromise(`docker exec ${config.MOSQUITTO_CONTAINER_NAME} kill -SIGHUP 1`);

    console.log('✅ Sync complete.');
    res.json({ success: true, message: 'Mosquitto synced and reloaded successfully' });

  } catch (err) {
    console.error('❌ Sync failed:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

const PORT = config.PORT || process.env.PORT || 3001;

// NEW ENDPOINT: Create users directly
app.post('/api/admin/users', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ success: false, error: 'Unauthorized: Missing Bearer token' });
    }

    const token = authHeader.split(' ')[1];

    // First verify the request is coming from a logged-in user
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return res.status(401).json({ success: false, error: 'Unauthorized: Invalid token' });
    }

    // Then strictly check if they are an admin with manage_users permission
    const { data: roleData, error: roleErr } = await supabase
      .from('admin_user_roles')
      .select('manage_users')
      .eq('user_id', user.id)
      .single();

    if (roleErr || !roleData || !roleData.manage_users) {
      return res.status(403).json({ success: false, error: 'Forbidden: Insufficient privileges' });
    }

    const { email, password, role_id } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Missing email or password' });
    }

    console.log(`👤 Admin ${user.email} is creating new user: ${email}`);

    // Create user with Service Role privileges
    const { data: newUser, error: createError } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true // bypass email confirmation
    });

    if (createError) throw createError;

    // If a role was provided, assign it immediately
    if (role_id) {
      // The trigger automatically gives 'Customer', so we might need to upsert/update
      // Let's just wait a moment for the trigger to finish, or manually update
      await new Promise(resolve => setTimeout(resolve, 500));

      const { error: roleAssignError } = await supabase
        .from('user_roles')
        .update({ role_id })
        .eq('user_id', newUser.user.id);

      // If the trigger hadn't fired yet (or we missed the update), try upsert
      if (roleAssignError) {
        await supabase.from('user_roles').upsert({ user_id: newUser.user.id, role_id });
      }
    }

    res.json({ success: true, user: newUser.user });
  } catch (err) {
    console.error('❌ Failed to create user:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// NEW ENDPOINT: Delete user
app.delete('/api/admin/users/:id', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ success: false, error: 'Unauthorized: Missing Bearer token' });
    }

    const token = authHeader.split(' ')[1];

    // Verify admin calling the API
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return res.status(401).json({ success: false, error: 'Unauthorized: Invalid token' });
    }

    const { data: roleData, error: roleErr } = await supabase
      .from('admin_user_roles')
      .select('manage_users')
      .eq('user_id', user.id)
      .single();

    if (roleErr || !roleData || !roleData.manage_users) {
      return res.status(403).json({ success: false, error: 'Forbidden: Insufficient privileges' });
    }

    const targetUserId = req.params.id;
    if (targetUserId === user.id) {
      return res.status(400).json({ success: false, error: 'Cannot delete yourself' });
    }

    console.log(`👤 Admin ${user.email} is deleting user: ${targetUserId}`);

    // Delete from auth.users using service role key
    const { error: deleteError } = await supabase.auth.admin.deleteUser(targetUserId);

    if (deleteError) throw deleteError;

    res.json({ success: true });
  } catch (err) {
    console.error('❌ Failed to delete user:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 MQTT Config Sync API running on port ${PORT}`);
});
